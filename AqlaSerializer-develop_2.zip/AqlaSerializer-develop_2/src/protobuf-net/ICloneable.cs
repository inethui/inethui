﻿#if PORTABLE
namespace System
{
    interface ICloneable
    {
        object Clone();
    }
}
#endif