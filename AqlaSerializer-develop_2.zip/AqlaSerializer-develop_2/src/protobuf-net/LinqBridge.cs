namespace AltLinq
{
}
