﻿// Modified by Vladyslav Taranov for AqlaSerializer, 2016

namespace QuickStart
{
    class Program
    {
        static void Main()
        {
            FileAccess.ShowFileAccess();
            Sockets.ShowSockets();
        }
    }
}
