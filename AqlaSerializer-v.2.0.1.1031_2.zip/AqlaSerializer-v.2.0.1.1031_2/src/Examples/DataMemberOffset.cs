﻿// Modified by Vladyslav Taranov for AqlaSerializer, 2016
using System.Runtime.Serialization;
using NUnit.Framework;
using AqlaSerializer;

namespace Examples
{
    [TestFixture]
    public class DataMemberOffset
    {
        [Test]
        public void TestOffset()
        { 
            DMO_First first = new DMO_First {Foo = 12};
            DMO_Second second = Serializer.ChangeType<DMO_First, DMO_Second>(first);

            Assert.AreEqual(first.Foo, second.Bar);
        }

    }

    [DataContract]
    public class DMO_First
    {
        [DataMember(Order = 5)]
        public int Foo { get; set; }
    }
    [DataContract]
    [ProtoBuf.ProtoContract(DataMemberOffset = 2)]
    public class DMO_Second
    {
        [DataMember(Order = 3)]
        public int Bar { get; set; }
    }

    [DataContract, ProtoBuf.ProtoContract]
    public class TypeWithProtosAndDataContract_UseAny
    {
        [ProtoBuf.ProtoMember(1)]
        public int Foo { get; set; }
        [DataMember(Order=2)]
        public int Bar { get; set; }
    }
    [DataContract, ProtoBuf.ProtoContract(UseProtoMembersOnly=true)]
    public class TypeWithProtosAndDataContract_UseProtoOnly
    {
        [ProtoBuf.ProtoMember(1)]
        public int Foo { get; set; }
        [DataMember(Order = 2)]
        public int Bar { get; set; }
    }
    [TestFixture]
    public class TestWeCanTurnOffNonProtoMarkers
    {
        [Test]
        public void TypeWithProtosAndDataContract_UseAny_ShouldSerializeBoth()
        {
            var orig = new TypeWithProtosAndDataContract_UseAny { Foo = 123, Bar = 456 };
            var clone = Serializer.DeepClone(orig);
            Assert.AreEqual(123, clone.Foo);
            Assert.AreEqual(456, clone.Bar);
        }
        [Test]
        public void TypeWithProtosAndDataContract_UseProtoOnly_ShouldSerializeFooOnly()
        {
            var orig = new TypeWithProtosAndDataContract_UseProtoOnly { Foo = 123, Bar = 456 };
            var clone = Serializer.DeepClone(orig);
            Assert.AreEqual(123, clone.Foo);
            Assert.AreEqual(0, clone.Bar);
        }
    }
}
